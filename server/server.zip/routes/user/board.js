/*
 * 게시판을 위한 라우팅 함수 정의
 *
 * @date 2016-11-10
 * @author Mike
 */
var getBoard = function(req, res) {
	console.log('board 모듈 안에 있는 getBoard 호출됨.');
/*	
	console.log('req.user : ' + req.user);
	console.dir(req.user) ;
	if(req.user) {
		res.render('./user/board.ejs');
	}else {
		res.redirect('./');
	}
*/	
	res.render('./user/board.ejs', {'user':req.user.userid});
};

var listStory = function(req, res) {
  
	// res.writeHead('200', {'Content-Type':'text/html;charset=utf8'});
	// res.write('<h2>게시판 글 목록 조회</h2>');
	// res.end();

	console.log('/board/liststory 패스 요청됨.');
	// res.render('/views/board/listboard.ejs', {message: req.flash('loginMessage')});

	var database = req.app.get('database');
	
    // 데이터베이스 객체가 초기화된 경우
	if (database.db) {
		// 1. 글 리스트

		var options = {"criteria": {bbs_id : req.query.bbs_id},
			"perPage": req.query.perPage,
			"curPage": req.query.curPage} ;

		// console.log(req);
		console.log(options);
		
		database.BoardModel.countByBbsId(options, function(err, count){
			if (err) {
				console.dir(err);
				res.json({success:false, message:err}) ;
				res.end();
			}else if (count) {
				// console.dir(results);
				database.BoardModel.findByBbsId(options, function(err, results) {
					var totalPage = Math.ceil(count/req.query.perPage);
					console.log("count : " + count + " totalPage : " + totalPage) ;
					var pageInfo = {
						"totalPage": totalPage,
						"perPage": req.query.perPage,
						"curPage": req.query.curPage
					};

					var resBody = {"pageInfo":pageInfo, "stories":results};

					// res.json(results);
					res.json(resBody);
					res.end();
				});
			} else {
				res.json({success:false, message:"No Data"}) ;
				res.end();
			}
		});
	} else {
		res.json({success:false, message:"DB connection Error"}) ;
		res.end();
	}

};

var insertStory = function(req, res) {
  
	// res.writeHead('200', {'Content-Type':'text/html;charset=utf8'});
	// res.write('<h2>게시판 글 목록 조회</h2>');
	// res.end();

	console.log('/board/insertstory 패스 요청됨.');
	// res.render('/views/board/listboard.ejs', {message: req.flash('loginMessage')});

	var database = req.app.get('database');
	
    // 데이터베이스 객체가 초기화된 경우
	if (database.db) {
		// 1. 글 리스트

		// console.log(req);
		var bbsId = req.body.bbs_id;
		var storyInfo = req.body.storyinfo ;
		var options = {"criteria": {"bbs_id" : bbsId}, "storyinfo":storyInfo} ;

		console.log(options);
		
		database.BoardModel.getMaxStoryId(options, function(err, result){
			if (err) {
				res.json({success:false, message:err}) ;
				res.end();
			}else if (result) {
				console.log(result);
				var maxStoryId = result.story_id + 1;
				console.log("MaxStoryId : " + maxStoryId);

				options.storyinfo.story_id = maxStoryId ;
				var tModel = new database.BoardModel(options.storyinfo) ;
				tModel.insertStory(function(err, result) {
					if(err) {
						console.log("Insert.... FAIL");
						res.json({success:false, message:"FAIL"}) ;
						res.end();
					}else {
						console.log("Insert.... OK");
						res.json({success:true, message:"OK"}) ;
						res.end();
					}
				});
			} else {
				res.json({success:false, message:"No Data"}) ;
				res.end();
			}
		});
	} else {
		res.json({success:false, message:"DB connection Error"}) ;
		res.end();
	}

};

var updateStory = function(req, res) {
  
	// res.writeHead('200', {'Content-Type':'text/html;charset=utf8'});
	// res.write('<h2>게시판 글 목록 조회</h2>');
	// res.end();

	console.log('/board/updatestory 패스 요청됨.');
	// res.render('/views/board/listboard.ejs', {message: req.flash('loginMessage')});

	var database = req.app.get('database');
	
    // 데이터베이스 객체가 초기화된 경우
	if (database.db) {
		// 1. 글 리스트

		// console.log(req);
		var bbsId = req.body.bbs_id;
		var storyInfo = req.body.storyinfo ;
		var options = {"criteria": {"bbs_id" : bbsId, "story_id": storyInfo.story_id}, "storyinfo":storyInfo} ;

		console.log(options);

		database.BoardModel.updateStory(options, function(err) {
			if(err) {
				console.log("Update.... FAIL " + err);
				res.json({success:false, message:"FAIL"}) ;
				res.end();
			}else {
				console.dir("Update.... OK ");
				res.json({success:true, message:"OK"}) ;
				res.end();
			}
		}) ;
/*		
		database.BoardModel.findOneAndUpdate(options.criteria, options.storyinfo, function(err) {
			if(err) {
				console.log("Update.... FAIL " + err);
				res.json({success:false, message:"FAIL"}) ;
				res.end();
			}else {
				console.dir("Update.... OK ");
				res.json({success:true, message:"OK"}) ;
				res.end();
		}
		}) ;
*/
	} else {
		res.json({success:false, message:"DB connection Error"}) ;
		res.end();
	}

};

var deleteStory = function(req, res) {
	console.log('/board/deletestory 패스 요청됨.');

	var database = req.app.get('database');
	if (database.db) {
		var bbsId = req.body.bbs_id;
		var storyInfo = req.body.storyinfo ;
		var options = {"criteria": {"bbs_id" : bbsId, "story_id": storyInfo.story_id}, "storyinfo":storyInfo} ;

		console.log(options);

		database.BoardModel.deleteStory(options, function(err) {
			if(err) {
				console.log("Delete.... FAIL " + err);
				res.json({success:false, message:"FAIL"}) ;
				res.end();
			}else {
				console.dir("Delete.... OK ");
				res.json({success:true, message:"OK"}) ;
				res.end();
			}
		}) ;
	} else {
		res.json({success:false, message:"DB connection Error"}) ;
		res.end();
	}
};

module.exports.getBoard = getBoard;
module.exports.listStory = listStory;
module.exports.insertStory = insertStory;
module.exports.updateStory = updateStory;
module.exports.deleteStory = deleteStory;
