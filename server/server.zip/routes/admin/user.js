/*
 * 사용자 정보
 *
 * @date 2018-02-07
 * @author Mike
 */
var getUser = function(req, res) {
	console.log('user 모듈 안에 있는 getUserList 호출됨.');
	res.render('./admin/userlist.ejs', {'user':req.user.userid});
};

var listUser = function(req, res) {
	console.log('/admin/listUser 패스 요청됨.');
	
	var pageInfo = {} ;
	var database = req.app.get('database');
	
    // 데이터베이스 객체가 초기화된 경우
	if (database.db) {
		var options = {"perPage": req.query.perPage,
			"curPage": req.query.curPage} ;
			console.log("perPage : " + options.perPage);
			console.log("curPage : " + options.curPage);

		database.UserModel.countUsers(function(err, count){
			console.log("count : " + count);
			if (err) {
				console.log(err);
				res.json({success:false, message:err}) ;
				res.end();
			}else if (count) {
				database.UserModel.findAll(options, function(err, results) {
					if(err) {
						console.log(err);
						res.json({success:false, message:"FAIL"}) ;
						res.end();
					}else {
						var totalPage = Math.ceil(count/req.query.perPage);
						console.log("11.. count : " + count + " totalPage : " + totalPage) ;
						var pageInfo = {
							"totalPage": totalPage,
							"perPage": req.query.perPage,
							"curPage": req.query.curPage
						};
						var resBody = {"pageInfo":pageInfo, "users":results};

						// res.json(results);
						// console.log(resBody);
						res.json(resBody);
						res.end();
						console.log("22.. count : " + count + " totalPage : " + totalPage) ;
					}
				});
			}
		});
	}
};

var insertUser = function(req, res) {
	console.log('/board/insertstory 패스 요청됨.');
	var database = req.app.get('database');
    // 데이터베이스 객체가 초기화된 경우
	if (database.db) {
		var userInfo = req.body.userinfo ;
		console.log("userid : [" + userInfo.userid + "]");
		database.UserModel.findByUserId(userInfo.userid, function(err, result){
			if (err) {
				res.json({success:false, message:err}) ;
				res.end();
			}else if (result.length > 0) {
				console.log(result);
				res.json({success:false, message:"Duplicated ID"}) ;
				res.end();
			}else {
				console.log("userInfo : [" + userInfo + "]");
				var tModel = new database.UserModel(userInfo) ;
				tModel.insertUser(function(err, result) {
					console.log("result : [" + result + "]");
					if(err) {
						console.log("Insert.... FAIL : [" + err + "]");
						res.json({success:false, message:"Insert FAIL"}) ;
						res.end();
					}else {
						console.log("Insert.... OK");
						res.json({success:true, message:"Insert OK"}) ;
						res.end();
					}
				});
			}
		});
	} else {
		res.json({success:false, message:"DB connection Error"}) ;
		res.end();
	}

};

var updateUser = function(req, res) {
  
	console.log('/admin/updateuser 패스 요청됨.');

	var database = req.app.get('database');
	
    // 데이터베이스 객체가 초기화된 경우
	if (database.db) {
		var userInfo = req.body.userinfo ;
		var options = {"criteria": {"userid" : userInfo.userid}, "userinfo":userInfo} ;

		console.log(options);

		database.UserModel.updateUser(options, function(err) {
			if(err) {
				console.log("Update.... FAIL " + err);
				res.json({success:false, message:"FAIL"}) ;
				res.end();
			}else {
				console.dir("Update.... OK ");
				res.json({success:true, message:"OK"}) ;
				res.end();
			}
		}) ;
	} else {
		res.json({success:false, message:"DB connection Error"}) ;
		res.end();
	}

};

var migratedb = function(req, res) {
	console.log('/admin/migratedb 패스 요청됨.');

	var lineNum = 0;
	var fs = require('fs'), readline= require('readline');
	var rdfile = "./public/data/t_user.sql";
	var userInfo = {};
	var options = {"criteria": {}, "userinfo":userInfo} ;

	var database = req.app.get('database');
	var rd = readline.createInterface({
		input : fs.createReadStream(rdfile),
		// output: process.stdout,
		// console:false
	});
	rd.on('line', function(line){
		// console.log(line);
		lineNum += 1 ;
		console.log("line Num [" + lineNum + "] ........................................");
		var tabs = line.split('	');
		if(lineNum == 1) {
			for(var i=0; i < tabs.length; i++) {
				console.log("[" + i + "] : [" + tabs[i] + "]");
			}
		}else {
			console.log("userid : [" + tabs[0] + "]");
			console.log("ipaddr : [" + tabs[2] + "]");
			console.log("name : [" + tabs[3] + "]");
			console.log("phone : [" + tabs[6] + "]");
			console.log("email : [" + tabs[7] + "]");
			console.log("machine_name : [" + tabs[8] + "]");
			console.log("grpcode : [" + tabs[9] + "]");
			console.log("create_at : [" + tabs[10] + "]");
			console.log("today_visit : [" + tabs[12] + "]");
			console.log("total_visit : [" + tabs[13] + "]");

			userInfo.userid = tabs[0].trim();
			userInfo.ipaddr = tabs[2].trim();
			userInfo.name = tabs[3].trim();
			userInfo.phone = tabs[6].trim();
			userInfo.email = tabs[7].trim();
			userInfo.machine_name = tabs[8].trim();
			userInfo.grpcode = tabs[9].trim();
			// userInfo.create_at = tabs[10];
			userInfo.today_visit = parseInt(tabs[12]);
			userInfo.total_visit = parseInt(tabs[13]);
			
			if(tabs[9].indexOf("SPOT") >= 0) {
				console.log("SPOT....................................");
				userInfo.route_gubun1= true ;
			}
			if(tabs[9].indexOf("FUTURES") >= 0) {
				console.log("FUTURES....................................");
				userInfo.route_gubun2= true ;
			}				
			if(tabs[9].indexOf("FUTURESB") >= 0) {
				console.log("FUTURES....................................");
				userInfo.route_gubun3= true ;
			}				
			if(tabs[9].indexOf("ORTEST") >= 0) {
				console.log("FUTURES....................................");
				userInfo.route_gubun4= true ;
			}				
			
			if(tabs[9].indexOf("YUGA") >= 0) {
				console.log("FUTURES....................................");
				userInfo.market_gubun1= true ;
			}				
			if(tabs[9].indexOf("KOSDAQ") >= 0) {
				console.log("FUTURES....................................");
				userInfo.market_gubun2= true ;
			}				
			if(tabs[9].indexOf("ELW") >= 0) {
				console.log("FUTURES....................................");
				userInfo.market_gubun3= true ;
			}				
			if(tabs[9].indexOf("OPT") >= 0) {
				console.log("FUTURES....................................");
				userInfo.market_gubun4= true ;
			}				
			if(tabs[9].indexOf("SUNMUL") >= 0) {
				console.log("FUTURES....................................");
				userInfo.market_gubun5= true ;
			}				
			if(tabs[9].indexOf("BOND") >= 0) {
				console.log("FUTURES....................................");
				userInfo.market_gubun6= true ;
			}				
			if(tabs[9].indexOf("MDTEST") >= 0) {
				console.log("FUTURES....................................");
				userInfo.market_gubun7= true ;
			}				

			// password 임의 처리
			userInfo.password = userInfo.userid + "11" ;

			if(database.db && userInfo.userid.length > 0) {
				console.log("line Num [" + lineNum + "] DB Insert...............");
				var tModel = new database.UserModel(userInfo) ;
				tModel.insertUser(function(err, result) {
					if(err) {
						console.log("Insert.... FAIL : " + userInfo.userid);
						console.log(err);
						// res.json({success:false, message:"Insert FAIL"}) ;
						// res.end();
					}else {
						console.log("Insert.... OK");
						// res.json({success:true, message:"Insert OK"}) ;
						// res.end();
					}
				});
			}
		}
		// line.split('	').forEach(function(element, index) {
		// 	console.log("[" + index + "] : [" + element + "]");
		// });
	});

	// Model.insertMany 사용하지 않음. 키값 중복시 전체 입력데이터 깨짐 (2018.02.14 ThreeOn)

	console.log("1......................................................");
	res.json({success:true, message:"Read Data"}) ;
	res.end();

};


module.exports.getUser = getUser;
module.exports.listUser = listUser;
module.exports.updateUser = updateUser;
module.exports.insertUser = insertUser;
module.exports.migratedb = migratedb;
