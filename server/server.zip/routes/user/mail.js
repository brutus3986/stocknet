/*
 * 메일리스트를 위한 라우팅 함수 정의
 *
 * @date 2017-03-07
 * @author ThreeOn
 */

var net = require('net');
var msg = require('../../config/message');
var config = require('../../config/config');

var listMail = function(req, res) {
  	console.log('/mail/listmail 패스 요청됨.');

	var database = req.app.get('database');
	if (database.db) {
		var options = {"criteria": {bbs_id : req.query.bbs_id},
			"perPage": req.query.perPage,
			"curPage": req.query.curPage} ;

		// console.log(req);
		console.log(options);
		
		database.MailModel.countByBbsId(options, function(err, count){
			if (err) {
				res.json({success:false, message:err}) ;
				res.end();
			}else if (count) {
				// console.dir(results);
				database.MailModel.findByBbsId(options, function(err, results) {
					var totalPage = Math.ceil(count/req.query.perPage);
					console.log("count : " + count + " totalPage : " + totalPage) ;
				// console.dir(results);
				var pageInfo = {
						"totalPage": totalPage,
						"perPage": req.query.perPage,
						"curPage": req.query.curPage
					};

					var resBody = {"pageInfo":pageInfo, "stories":results};

					// res.json(results);
					res.json(resBody);
					res.end();
				});
			} else {
				res.json({success:false, message:msg.err.DB_NODATA}) ;
				res.end();
			}
		});
	} else {
		res.json({success:false, message:msg.err.DB_CONNECT}) ;
		res.end();
	}

};

var insertMail = function(req, res) {
	console.log('/mail/insertmail 패스 요청됨.');

	var database = req.app.get('database');
	if (database.db) {
		var bbsId = req.body.bbs_id;
		var storyInfo = req.body.storyinfo ;
		var options = {"criteria": {"bbs_id" : bbsId}, "storyinfo":storyInfo} ;

		// console.log(options);
		
		database.MailModel.getMaxMailId(options, function(err, result){
			if (err) {
				console.log(err);
				res.json({success:false, message:err}) ;
				res.end();
			}else {
				console.log(result);
				if(result) {
					console.log("1..............");
					var maxStoryId = result.story_id + 1;
				}else {
					console.log("2..............");
					var maxStoryId = 1;
				}
				console.log("MaxStoryId : " + maxStoryId);

				options.storyinfo.story_id = maxStoryId ;
				var tModel = new database.MailModel(options.storyinfo) ;
				tModel.insertMail(function(err, result) {
					if(err) {
						console.log("Insert.... FAIL");
						res.json({success:false, message:"FAIL"}) ;
						res.end();
					}else {
						console.log("Insert.... OK");
						res.json({success:true, message:"OK"}) ;
						res.end();
					}
				});
			}
		});
	} else {
		res.json({success:false, message:msg.err.DB_CONNECT}) ;
		res.end();
	}

};

var updateMail = function(req, res) {
	console.log('/mail/updatemail 패스 요청됨.');

	var database = req.app.get('database');
	if (database.db) {
		var bbsId = req.body.bbs_id;
		var storyInfo = req.body.storyinfo ;
		var options = {"criteria": {"bbs_id" : bbsId, "story_id": storyInfo.story_id}, "storyinfo":storyInfo} ;

		console.log(options);

		database.MailModel.updateMail(options, function(err) {
			if(err) {
				console.log("Update.... FAIL " + err);
				res.json({success:false, message:"FAIL"}) ;
				res.end();
			}else {
				console.dir("Update.... OK ");
				res.json({success:true, message:"OK"}) ;
				res.end();
			}
		}) ;
	} else {
		res.json({success:false, message:msg.err.DB_CONNECT}) ;
		res.end();
	}

};

var deleteMail = function(req, res) {
	console.log('/mail/deletemail 패스 요청됨.');

	var database = req.app.get('database');
	if (database.db) {
		var bbsId = req.body.bbs_id;
		var storyInfo = req.body.storyinfo ;
		var options = {"criteria": {"bbs_id" : bbsId, "story_id": storyInfo.story_id}, "storyinfo":storyInfo} ;

		console.log(options);

		database.MailModel.deleteMail(options, function(err) {
			if(err) {
				console.log("Delete.... FAIL " + err);
				res.json({success:false, message:"FAIL"}) ;
				res.end();
			}else {
				console.dir("Delete.... OK ");
				res.json({success:true, message:"OK"}) ;
				res.end();
			}
		}) ;
	} else {
		res.json({success:false, message:msg.err.DB_CONNECT}) ;
		res.end();
	}
};

var sendMail = function(req, res) {
	console.log('/mail/sendmail 패스 요청됨.');
	var bbsId = req.body.bbs_id;
	var storyInfo = req.body.storyinfo ;
	var options = {"criteria": {"bbs_id" : bbsId, "story_id": storyInfo.story_id}, "storyinfo":storyInfo} ;

	var buff = {
		tr_cd: "EMSSEND",
		domain: "PBCRM",
		msgSeq: "1",
		fromAddress: "sykim7@koscom.co.kr",
		body: "",
		subject: "",
		toAddress: [],
	}

	var tArr = storyInfo.receiver.split(',');
	tArr.forEach(function(item, index){
		item = item.trim();
	});
	buff.toAddress = tArr ;
	buff.subject = storyInfo.title ;
	buff.body = storyInfo.contents ;

	console.log(buff);

	console.log("sendMailtoTCP.........1");

	var socketId = net.connect(config.mail_port, config.mail_host, function() {
		console.log('   local = %s:%s', this.localAddress, this.localPort);
		console.log('   remote = %s:%s', this.remoteAddress, this.remotePort);
		this.setTimeout(3000);
		this.setEncoding('utf8');
		
		console.log("socket write........");
		socketId.write(storyInfo);
	});

	console.log("sendMailtoTCP.........1");
	socketId.on('data', function(data) {
		console.log(" From Server: [" + data + "]");
		this.end();
		if(data.rec_cd === "OK") {
			updateSendCntMail(req, options);
			res.json({success:true, message:msg.succ.MAIL_SEND}) ;
			res.end();
		}else {
			res.json({success:false, message:msg.err.MAIL_TCP}) ;
			res.end();
		}
	});

	console.log("sendMailtoTCP.........2");
	socketId.on('end', function() {
		console.log('Client disconnected');
	});
	console.log("sendMailtoTCP.........3");
	socketId.on('error', function(err) {
		console.log('Socket Error: ', err);
	});
	console.log("sendMailtoTCP.........4");
	socketId.on('timeout', function() {
		console.log('Socket Timed Out');
		socketId.destroyed();
	});
	console.log("sendMailtoTCP.........5");
	socketId.on('close', function() {
		console.log('Socket Closed');
	});
	console.log("sendMailtoTCP.........7");
}

var updateSendCntMail = function(req, options) {
	var database = req.app.get('database');
	if (database.db) {
		// console.dir(options);
		database.MailModel.getSendCnt(options, function(err, result){
			if (err) {
				console.log(err);
				res.json({success:false, message:err}) ;
				res.end();
			}else {
				// console.log(result);
				if(result) {
					console.log("1..............");
					var sendCnt = result.send_cnt + 1;
				}else {
					console.log("2..............");
					var sendCnt = result.send_cnt + 0;
				}
				console.log("sendCnt : " + sendCnt);
			}				

			options.storyinfo.send_cnt = sendCnt ;
			database.MailModel.updateMail(options, function(err) {
				if(err) {
					console.log("mail.js. Update.... FAIL " + err);
					// res.json({success:false, message:"FAIL"}) ;
					// res.end();
				}else {
					console.dir("mail.js. Update.... OK ");
					// res.json({success:true, message:"OK"}) ;
					// res.end();
				}
			});
		});			
	} else {
		console.log("mail.js. DB NOT CONNECT");
		// res.json({success:false, message:msg.err.DB_CONNECT}) ;
		// res.end();
	}
}

module.exports.listMail = listMail;
module.exports.insertMail = insertMail;
module.exports.updateMail = updateMail;
module.exports.deleteMail = deleteMail;
module.exports.sendMail = sendMail;
