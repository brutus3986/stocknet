/**
 * 데이터베이스 스키마를 정의하는 모듈
 *
 * @date 2016-11-10
 * @author Mike
 */

var Schema = {};

Schema.createSchema = function(mongoose) {
	
	// 스키마 정의
	var BoardSchema = mongoose.Schema({
		bbs_id: {type: Number, required: true, index: 'hashed', 'default':''}
	    , story_id: {type: Number,  required: true, index: 'hashed', 'default':0}
	    , title: {type: String,  required: true, 'default':''}
	    , contents: {type: String,  required: true, 'default':''}
	    , writer: {type: String,  required: true, 'default':''}
	    , views: {type: Number,  'default':133}
	    , created_at: {type: Date, index: {unique: false}, 'default': Date.now}
	    , updated_at: {type: Date, index: {unique: false}, 'default': Date.now} 
	    , display: {type: Boolean, 'default':true}
	    , notice: {type: Boolean, 'default':false}
	});
	
	// 값이 유효한지 확인하는 함수 정의
	var validatePresenceOf = function(value) {
		return value && value.length;
	};
		
	// 저장 시의 트리거 함수 정의 (password 필드가 유효하지 않으면 에러 발생)
/*	
	BoardSchema.pre('save', function(next) {
		if (!this.isNew) return next();
	
		if (!validatePresenceOf(this.title)) {
			next(new Error('유효하지 않은 title 필드입니다.'));
		}else if (!validatePresenceOf(this.contents)) {
			next(new Error('유효하지 않은 contents 필드입니다.'));
		} else {
			next();
		}
	})
*/	
	
	// 입력된 칼럼의 값이 있는지 확인
/*	
	BoardSchema.path('bbs_id').validate(function (bbs_id) {
		return bbs_id.length;
	}, 'bbs_id 칼럼의 값이 없습니다.');
	
	BoardSchema.path('story_id').validate(function (story_id) {
		return story_id.length;
	}, 'story_id 칼럼의 값이 없습니다.');
*/	
	
	// 모델 객체에서 사용할 수 있는 메소드 정의
	BoardSchema.statics = {
		findByStoryId: function(bbs_id, story_id, callback) {
			return this.find({bbs_id:bbs_id, story_id:story_id}, callback);
		},
		findByBbsId: function(options, callback) {
			return this.find(options.criteria)
			.sort({'story_id': -1})
			.skip(Number(options.perPage) * (Number(options.curPage)-1))
			.limit(Number(options.perPage))
			.exec(callback);
		},
		countByBbsId: function(options, callback) {
			return this.find(options.criteria).count().exec(callback);
		},
		getMaxStoryId: function(options, callback) {
			return this.findOne(options.criteria).sort({story_id:-1}).exec(callback);
		},
		updateStory: function(options, callback) {
			// update() 사용 에러 사전 방지
			return this.findOneAndUpdate(options.criteria, options.storyinfo).exec(callback);
		},
		deleteStory: function(options, callback) {
			// delete() 사용 에러 사전 방지
			return this.findOneAndRemove(options.criteria, options.storyinfo).exec(callback);
		}
	}

	BoardSchema.methods = {
		insertStory: function(callback) {
			return this.save(callback);
		},
	}
	return BoardSchema;
};

// module.exports에 UserSchema 객체 직접 할당
module.exports = Schema;