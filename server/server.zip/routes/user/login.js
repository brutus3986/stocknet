/*
 * Login 위한 라우팅 함수 정의
 *
 * @date 2016-11-10
 * @author Mike
 */
var checkLogin = function(req, res) {
	console.log('login 모듈 안에 있는 checkLogin 호출됨.');

	// console.dir(req);
	var userid = req.body.userid ;
	var password = req.body.password ;
	console.log("userid : [" + userid + "]  password : [" + password + "]");

	var UM = req.app.get('database').UserModel;
	UM.findByUserId(userid, function(err, user) {
		if (err) { 
			console.log("Error.......: " + err);
			res.json({success:false, message:err}) ;
			res.end();
		}

		console.log("user length : " + user.length) ;
		console.log("user : [" + user + "]") ;
		// 등록된 사용자가 없는 경우
		if (user.length > 0) {
			console.log('계정이 일치.111');
			res.json({success:true, message:"OK", userid: userid, username: user[0].name}) ;
			res.end();
		}else {
			console.log('계정이 일치하지 않음.');
			res.json({success:false, message:"FAIL"}) ;
			res.end();
		}
	});

};

module.exports.checkLogin = checkLogin;
