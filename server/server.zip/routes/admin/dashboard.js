/*
 * DASHBOARD를 위한 라우팅 함수 정의
 *
 * @date 2017-12-28
 * @author ThreeOn
 */
var getDashBoard = function(req, res) {
	console.log('board 모듈 안에 있는 getDashBoard 호출됨.');
	res.render('./admin/dashboard.ejs');
}

module.exports.getDashBoard = getDashBoard;
