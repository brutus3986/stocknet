
/*
 * 설정
 */

module.exports = {
    err: {
        DB_CONNECT:'DB CONNECTION ERROR. CALL THE MANAGER (7968).',
        DB_NODATA:'NO DATA DB.',
        MAIL_TCP:'MAIL TCP ERROR. CALL THE MANAGER (7968).',
    },
    succ: {
        MAIL_SEND: '메일이 정상적으로 발송되었습니다.',
    }
}