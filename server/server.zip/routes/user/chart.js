/*
 * 차트을 위한 라우팅 함수 정의
 *
 * @date 2017-12-28
 * @author ThreeOn
 */
var getChart = function (req, res) {
	console.log('chart 모듈 안에 있는 getChart 호출됨.');

	res.render('./user/chart.ejs', {
		'user': req.user.userid
	});
};

var getChartTerm = function (req, res) {
	console.log('chart 모듈 안에 있는 getChartTerm 호출됨.');
	res.render('./user/chartterm.ejs', {
		'user': req.user.userid
	});
};

var getChartList = function (req, res) {
	console.log('chart 모듈 안에 있는 getChartList 호출됨.');

	var indate = req.query.indate;
	var gubun1 = req.query.gubun1; // 표기 방식
	var gubun2 = req.query.gubun2; // 대분류
	var gubun3 = req.query.gubun3; // 소분류1
	var gubun4 = req.query.gubun4; // 소분류2

	console.log("indate : " + indate);
	console.log("gubun1 : " + gubun1);
	console.log("gubun2 : " + gubun2);
	console.log("gubun3 : " + gubun3);

	// var         chartlist = ["./traffic/2015-07-19/P_XXXX_0_02425.png",
	// 	"./traffic/2015-07-19/P_YUHWA_SPOT_1_00180.png",
	// ];

	var fs = require('fs');
	var rddir = "./public/traffic/" + indate + "/";

	fs.readdir(rddir, function (err, data) {
		var resBody = {};
		var resList = [];
		var dataList = [];

		if (err) {
			resBody = {
				"success": false,
				"message": "해당일자에 데이터가 존재하지 않습니다!"
			};
			console.log(resBody);
		} else {
			resList = data;
			if (gubun1 == 1) {
				resList = filterArr(resList, "_1_");
			} else if (gubun1 == 2) {
				resList = filterArr(resList, "_0_");
			} else {
				// 전체 조회
			}

			if (gubun2 == 1) {
				if (gubun3 == 1) {
					resList = filterArr(resList, "_SPOT_");
				} else if (gubun3 == 2) {
					resList = filterArr(resList, "_FUTURES_");
				} else if (gubun3 == 3) {
					resList = filterArr(resList, "_FUTUREB_");
				} else if (gubun3 == 4) {
					resList = filterArr(resList, "_ORTEST_");
				}
			} else if (gubun2 == 2) {
				if (gubun4 == 1) {
					resList = filterArr(resList, "_SPOT_");
				} else if (gubun4 == 2) {
					resList = filterArr(resList, "_KOSDAQ_");
				} else if (gubun4 == 3) {
					resList = filterArr(resList, "_ELW_");
				} else if (gubun4 == 4) {
					resList = filterArr(resList, "_OPT_");
				} else if (gubun4 == 5) {
					resList = filterArr(resList, "_SUNMUL_");
				} else if (gubun4 == 6) {
					resList = filterArr(resList, "_BOND_");
				} else if (gubun4 == 7) {
					resList = filterArr(resList, "_MDTEST_");
				} else {
					// 전체 조회
				}
			} else {
				// 전체 조회
			}
			// resList.forEach(function(el, idx, array) {
			// 	array[idx] = "./traffic/2015-07-19/" + el ;
			// });
			/*
			resList = resList.map(function(val) {
				val = "./traffic/" + indate + "/" + val ;
				return val ;
			});
			*/

			resList.forEach(function (el, idx, array) {
				var clist = {
					'imgsrc': "",
					'xlssrc': ""
				};

				// console.log("el : ", el);
				clist.imgsrc = "./Traffic/" + indate + "/" + el;
				el = el.replace("png", "csv");
				clist.xlssrc = "./Traffic_Excel/" + indate + "/" + el;
				// console.log(clist);
				dataList.push(clist);
			});
			// console.log(data) ;


			resBody = {
				"success": true,
				"clist": dataList
			};
			// console.log(resBody);
		}
		res.json(resBody);
		res.end();
	});

};

var filterArr = function (arr, str) {
	arr = arr.filter(function (val) {
		return val.indexOf(str) !== -1;
	});
	return arr;
}

module.exports.getChart = getChart;
module.exports.getChartTerm = getChartTerm;
module.exports.getChartList = getChartList;