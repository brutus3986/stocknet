
/*
 * 설정
 */

module.exports = {
	server_port: 8024,
	db_url: 'mongodb://localhost:27017/pbcrm',
	db_schemas: [
	    {file:'./user_schema', collection:'users', schemaName:'UserSchema', modelName:'UserModel'}
	    ,{file:'./board_schema', collection:'boards', schemaName:'BoardSchema', modelName:'BoardModel'}
	    ,{file:'./mail_schema', collection:'mails', schemaName:'MailSchema', modelName:'MailModel'}
    ],
    mail_port: 4021,
    // mail_host: 148.0.44.18, // 웹운영
    mail_host: "148.0.30.210", // 웹테스트
	route_info: [
        {file:'./user/login', path:'/login', method:'checkLogin', type:'post'}
        ,{file:'./user/mail', path:'/mail/listmail', method:'listMail', type:'get'}
        ,{file:'./user/mail', path:'/mail/insertmail', method:'insertMail', type:'post'}
        ,{file:'./user/mail', path:'/mail/updatemail', method:'updateMail', type:'post'}
        ,{file:'./user/mail', path:'/mail/deletemail', method:'deleteMail', type:'post'}
        ,{file:'./user/mail', path:'/mail/sendmail', method:'sendMail', type:'post'}
        ,{file:'./user/board', path:'/board', method:'getBoard', type:'get'}
        ,{file:'./user/board', path:'/board/liststory', method:'listStory', type:'get'}
        ,{file:'./user/board', path:'/board/insertstory', method:'insertStory', type:'post'}
        ,{file:'./user/board', path:'/board/updatestory', method:'updateStory', type:'post'}
        ,{file:'./user/board', path:'/board/deletestory', method:'deleteStory', type:'post'}
        ,{file:'./user/chart', path:'/chart', method:'getChart', type:'get'}
        ,{file:'./user/chart', path:'/chart/listchart', method:'getChartList', type:'get'}
        ,{file:'./user/chart', path:'/chartterm', method:'getChartTerm', type:'get'}
        ,{file:'./admin/user', path:'/admin/user', method:'getUser', type:'get'}
        ,{file:'./admin/user', path:'/admin/listuser', method:'listUser', type:'get'}
        ,{file:'./admin/user', path:'/admin/updateuser', method:'updateUser', type:'post'}
        ,{file:'./admin/user', path:'/admin/insertuser', method:'insertUser', type:'post'}
        ,{file:'./admin/user', path:'/admin/migratedb', method:'migratedb', type:'get'}
        ,{file:'./admin/dashboard', path:'/admin/dashboard', method:'getDashBoard', type:'get'}
	]
}